from flask import Flask,render_template,request
import mysql.connector

def getConnection():
     con = mysql.connector.connect(
          host="localhost",
          user="root",
          password = "root",
          database="project"
     )
     return con

app = Flask("__name__")

@app.route("/")
def load():
     return render_template("index.html")

@app.route("/datasent",methods=["POST"])
def getData(): 
     sid = request.form["sid"]
     sname = request.form["sname"]
     sbranch = request.form["sbranch"]
     
     conn = getConnection()
     cmd = conn.cursor()
     cmd.execute("INSERT INTO STUDENT VALUES(%s,%s,%s)",(sid,sname,sbranch))
     conn.commit()
     conn.close()
     
     return "data inserted to your table go check !!!!"

if __name__ == "__main__":
     app.run(debug=True)

