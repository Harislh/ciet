import mysql.connector

def getConnection():
     a = mysql.connector.connect(
          host="localhost",
          user="root",
          password="root",
          database="project"
     )
     return a

def insertDATA():
     print("Enter student Details: ")
     sid = int(input("Enter student id: "))
     sname = input("Enter student name: ")
     sbranch = input("Enter student branch: ")
     
     conn = getConnection()
     cmd = conn.cursor()
     cmd.execute("INSERT INTO STUDENT VALUES(%s,%s,%s)",(sid,sname,sbranch))
     print("Data inserted!!!!")
     conn.commit()
     conn.close()
     
     
insertDATA()
     