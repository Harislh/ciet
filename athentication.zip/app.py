from flask import Flask,render_template,request,redirect,session
from dbConnetion import getConnection

app = Flask("__name__")

app.secret_key = "xyz"

@app.route('/')
def home():
     return render_template("index.html")

@app.route("/dashboard")
def das():
     if "admin" not in session:
          return redirect("/")
     else:
          return render_template("dashbord.html",name=session["admin"])

@app.route("/login",methods=["POST"])
def login():
     u = request.form["userNN"]
     p = request.form.get("passNN")
         
     # write sql logic to retrive user credentials
     conn = getConnection()
     cmd = conn.cursor()
     cmd.execute("SELECT * FROM USERS where user=%s and password=%s",(u,p))
     result = cmd.fetchone()
     conn.close()
     if result != None:
          session["admin"] = u
          return redirect("/dashboard")
     else:
          return "Invalid Credentials"
     
@app.route("/logout")
def logout():
     session.clear()
     return redirect("/")

if __name__ == "__main__":
     app.run(debug=True)